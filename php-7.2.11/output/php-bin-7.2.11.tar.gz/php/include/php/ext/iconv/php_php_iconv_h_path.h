#define PHP_ICONV_H_PATH </home/work/compile/php7/php-7.2.11/.tmp/build/../third/include/iconv.h>
