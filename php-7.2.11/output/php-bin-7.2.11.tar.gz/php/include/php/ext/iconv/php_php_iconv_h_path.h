#define PHP_ICONV_H_PATH </home/work/php/php-7.2.11/.tmp/build/../third/include/iconv.h>
